class ApiLogDomainService(object):
    def __enter__(self) -> 'ApiLogDomainService':
        return self

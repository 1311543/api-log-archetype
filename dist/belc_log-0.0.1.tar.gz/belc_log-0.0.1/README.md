# belc-dlk-api-log-archetype
Api Log connector
# belc-dlk-archetype-aws
Concept test about belcorp aws tools.
* **S3** - service that exposes 2 REST end points to Campaign Manager. One to submit request and another to check status of processing
* **EMR** - service that receives and processes all updates
* **STEP FUNCTIONS** – service that notifies Campaign Manager (if callback url is passed in the request)
